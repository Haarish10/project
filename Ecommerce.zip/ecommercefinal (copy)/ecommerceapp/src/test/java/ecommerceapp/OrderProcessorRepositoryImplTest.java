package ecommerceapp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import ecommerceapp.entity.Product;
import ecommerceapp.dao.OrderProcessorRepositoryImpl;
import ecommerceapp.util.DBConnUtil;

import java.sql.Connection;
import java.sql.SQLException;

public class OrderProcessorRepositoryImplTest {

    private OrderProcessorRepositoryImpl orderProcessor;

    @BeforeEach
    public void setUp() {
        try {
            Connection connection = DBConnUtil.getDBConn();
            orderProcessor = new OrderProcessorRepositoryImpl(connection);
        } catch (SQLException e) {
            fail("Failed to establish database connection: " + e.getMessage());
        }
    }

    @Test
    public void testCreateProduct() {
        Product product = new Product(0, "Test Product", 10.0, "Test Description", 100);
        try {
            boolean result = orderProcessor.createProduct(product);
            assertTrue(result);
        } catch (Exception e) {
            fail("Failed to create product: " + e.getMessage());
        }
    }
}
