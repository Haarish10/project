package ecommerceapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil {
    public static Connection getDBConn() throws SQLException {
        try {
            // Register the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            // If the driver class is not found, print the error and return null
            System.out.println("MySQL JDBC driver not found");
            e.printStackTrace();
            return null;
        }

        String url = "jdbc:mysql://localhost:3306/Ecommerce";
        String username = "root";
        String password = "Haarishraj&10";

        return DriverManager.getConnection(url, username, password);
    }
}
