package ecommerceapp.mainmod;

import ecommerceapp.dao.OrderProcessorRepositoryImpl;
import ecommerceapp.entity.*;
import ecommerceapp.util.*;
import ecommerceapp.exception.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

@SuppressWarnings("unused")
public class MainModule {
    private static OrderProcessorRepositoryImpl orderProcessor = new OrderProcessorRepositoryImpl(null);
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        try {
            Connection connection = DBConnUtil.getDBConn();
            orderProcessor = new OrderProcessorRepositoryImpl(connection);
        } catch (SQLException e) {
            System.out.println("Failed to establish database connection: " + e.getMessage());
            return;
        }

        while (true) {
            System.out.println("1. Register Customer");
            System.out.println("2. Create Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Add to Cart");
            System.out.println("5. View Cart");
            System.out.println("6. Place Order");
            System.out.println("7. View Customer Order");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    registerCustomer();
                    break;
                case 2:
                    createProduct();
                    break;
                case 3:
                    deleteProduct();
                    break;
                case 4:
                    addToCart();
                    break;
                case 5:
                    viewCart();
                    break;
                case 6:
                    placeOrder();
                    break;
                case 7:
                    viewCustomerOrder();
                    break;
                case 8:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 8.");
            }
        }
    }

    private static void registerCustomer() {
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();
        System.out.print("Enter customer password: ");
        String password = scanner.nextLine();

        Customer customer = new Customer(0, name, email, password);
        boolean success = orderProcessor.createCustomer(customer);
        if (success) {
            System.out.println("Customer registered successfully!");
        } else {
            System.out.println("Failed to register customer.");
        }
    }

    private static void createProduct() {
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter product price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter product description: ");
        String description = scanner.nextLine();
        System.out.print("Enter product stock quantity: ");
        int stockQuantity = scanner.nextInt();
        scanner.nextLine();

        Product product = new Product(0, name, price, description, stockQuantity);
        boolean success = orderProcessor.createProduct(product);
        if (success) {
            System.out.println("Product created successfully!");
        } else {
            System.out.println("Failed to create product.");
        }
    }

    private static void deleteProduct() {
        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        boolean success = orderProcessor.deleteProduct(productId);
        if (success) {
            System.out.println("Product deleted successfully!");
        } else {
            System.out.println("Failed to delete product.");
        }
    }

    private static void addToCart() {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine();

        Customer customer = new Customer(customerId, "", "", "");
        Product product = new Product(productId, "", 0, "", 0);
        boolean success = orderProcessor.addToCart(customer, product, quantity);
        if (success) {
            System.out.println("Product added to cart successfully!");
        } else {
            System.out.println("Failed to add product to cart.");
        }
    }

    private static void viewCart() {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        Customer customer = new Customer(customerId, "", "", "");
        List<Product> productList = orderProcessor.getAllFromCart(customer);
        if (productList != null && !productList.isEmpty()) {
            System.out.println("Products in cart:");
            for (Product product : productList) {
                System.out.println(product.getName() + " - Quantity: " + product.getStockQuantity());
            }
        } else {
            System.out.println("No products in cart.");
        }
    }

    private static void placeOrder() {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter shipping address: ");
        String shippingAddress = scanner.nextLine();

        Customer customer = new Customer(customerId, "", "", "");

        // Initialize an empty list for productList
        List<Map<Product, Integer>> productList = new ArrayList<>();
        boolean success = orderProcessor.placeOrder(customer, productList, shippingAddress);
        if (success) {
            System.out.println("Order placed successfully!");
        } else {
            System.out.println("Failed to place order.");
        }
    }

    private static void viewCustomerOrder() {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();

        List<Map<Product, Integer>> orders = orderProcessor.getOrdersByCustomer(customerId);
        if (orders != null && !orders.isEmpty()) {
            System.out.println("Customer's Orders:");
            for (Map<Product, Integer> order : orders) {
                for (Map.Entry<Product, Integer> entry : ((Map<Product, Integer>) order).entrySet()) {
                    System.out.println("Product: " + entry.getKey().getName() + ", Quantity: " + entry.getValue());
                }
            }
        } else {
            System.out.println("No orders found for the customer.");
        }
    }
}
