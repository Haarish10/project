package ecommerceapp.dao;

import ecommerceapp.entity.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderProcessorRepositoryImpl implements OrderProcessorRepository {
    private final Connection connection;

    public OrderProcessorRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public boolean createProduct(Product product) {
        String sql = "INSERT INTO products (name, price, description, stock_quantity) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, product.getName());
            statement.setDouble(2, product.getPrice());
            statement.setString(3, product.getDescription());
            statement.setInt(4, product.getStockQuantity());
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean createCustomer(Customer customer) {
        String sql = "INSERT INTO customers (name, email, password) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, customer.getName());
            statement.setString(2, customer.getEmail());
            statement.setString(3, customer.getPassword());
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteProduct(int productId) {
        String sql = "DELETE FROM products WHERE product_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, productId);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteCustomer(int customerId) {
        String sql = "DELETE FROM customers WHERE customer_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, customerId);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean addToCart(Customer customer, Product product, int quantity) {
        String sql = "INSERT INTO cart (customer_id, product_id, quantity) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, customer.getCustomerId());
            statement.setInt(2, product.getProductId());
            statement.setInt(3, quantity);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean removeFromCart(Customer customer, Product product) {
        String sql = "DELETE FROM cart WHERE customer_id = ? AND product_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, customer.getCustomerId());
            statement.setInt(2, product.getProductId());
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Product> getAllFromCart(Customer customer) {
        List<Product> productList = new ArrayList<>();
        String sql = "SELECT p.* FROM products p JOIN cart c ON p.product_id = c.product_id WHERE c.customer_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, customer.getCustomerId());
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Product product = new Product();
                product.setProductId(resultSet.getInt("product_id"));
                product.setName(resultSet.getString("name"));
                product.setPrice(resultSet.getDouble("price"));
                product.setDescription(resultSet.getString("description"));
                product.setStockQuantity(resultSet.getInt("stock_quantity"));
                productList.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }

    @Override
    public boolean placeOrder(Customer customer, List<Map<Product, Integer>> productList, String shippingAddress) {
        String orderSql = "INSERT INTO orders (customer_id, order_date, total_price, shipping_address) VALUES (?, CURRENT_TIMESTAMP, ?, ?)";
        try (PreparedStatement orderStatement = connection.prepareStatement(orderSql,
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            orderStatement.setInt(1, customer.getCustomerId());
            double totalPrice = calculateTotalPrice(productList);
            orderStatement.setDouble(2, totalPrice);
            orderStatement.setString(3, shippingAddress);
            int rowsAffected = orderStatement.executeUpdate();
            if (rowsAffected > 0) {
                ResultSet generatedKeys = orderStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int orderId = generatedKeys.getInt(1);
                    String orderItemsSql = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)";
                    try (PreparedStatement orderItemsStatement = connection.prepareStatement(orderItemsSql)) {
                        for (Map<Product, Integer> item : productList) {
                            for (Map.Entry<Product, Integer> entry : item.entrySet()) {
                                orderItemsStatement.setInt(1, orderId);
                                orderItemsStatement.setInt(2, entry.getKey().getProductId());
                                orderItemsStatement.setInt(3, entry.getValue());
                                orderItemsStatement.addBatch();
                            }
                        }
                        orderItemsStatement.executeBatch();
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private double calculateTotalPrice(List<Map<Product, Integer>> productList) {
        double totalPrice = 0;
        for (Map<Product, Integer> item : productList) {
            for (Map.Entry<Product, Integer> entry : item.entrySet()) {
                totalPrice += entry.getKey().getPrice() * entry.getValue();
            }
        }
        return totalPrice;
    }

    @Override
    public List<Map<Product, Integer>> getOrdersByCustomer(int customerId) {
        List<Map<Product, Integer>> orders = new ArrayList<>();
        String sql = "SELECT p.*, oi.quantity FROM products p JOIN order_items oi ON p.product_id = oi.product_id JOIN orders o ON o.order_id = oi.order_id WHERE o.customer_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, customerId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Map<Product, Integer> orderDetails = new HashMap<>();
                Product product = new Product();
                product.setProductId(resultSet.getInt("product_id"));
                product.setName(resultSet.getString("name"));
                product.setPrice(resultSet.getDouble("price"));
                product.setDescription(resultSet.getString("description"));
                product.setStockQuantity(resultSet.getInt("stock_quantity"));
                int quantity = resultSet.getInt("quantity");
                orderDetails.put(product, quantity);
                orders.add(orderDetails);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
}
