package ecommerceapp.dao;

import ecommerceapp.entity.*;
import java.util.List;
import java.util.Map;

public interface OrderProcessorRepository {

    boolean createProduct(Product product) throws Exception;

    boolean createCustomer(Customer customer) throws Exception;

    boolean deleteProduct(int productId) throws Exception;

    boolean deleteCustomer(int customerId) throws Exception;

    boolean addToCart(Customer customer, Product product, int quantity) throws Exception;

    boolean removeFromCart(Customer customer, Product product) throws Exception;

    List<Product> getAllFromCart(Customer customer) throws Exception;

    boolean placeOrder(Customer customer, List<Map<Product, Integer>> cartContents, String shippingAddress)
            throws Exception;

    List<Map<Product, Integer>> getOrdersByCustomer(int customerId) throws Exception;
}
